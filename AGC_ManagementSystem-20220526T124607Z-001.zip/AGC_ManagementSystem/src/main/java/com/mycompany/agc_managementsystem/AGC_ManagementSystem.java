package com.mycompany.agc_managementsystem;

import agc_managementsystem.Forms.Progress;

public class AGC_ManagementSystem {

    public static void main(String[] args) {
        
        // Main controller here
        
        boolean progressed = false;
        if(!progressed) {
            Progress p = new Progress();
            p.setVisible(true);

        }
    }
}
