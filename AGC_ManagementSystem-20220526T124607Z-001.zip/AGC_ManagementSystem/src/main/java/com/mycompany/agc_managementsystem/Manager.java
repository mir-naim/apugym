package com.mycompany.agc_managementsystem;

public class Manager extends User {

    public Manager(String ID) {
        super(ID);
    }
    
    // Manager's features here
    //
    //
    //
    //Profile
    
}
